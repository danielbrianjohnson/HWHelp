public class Contributor {
    private String name;
    private String city;
    private String country;
    private String phone;
    private double contribution;
    private int id;

    public Contributor(String name, String city, String country, String phone, double contribution, int id) {
        this.name = name;
        this.city = city;
        this.country = country;
        this.phone = phone;
        this.contribution = contribution;
        this.id = id;
    }
    
    public int hashFunction() {
        //defined in IP 2
    }
    
    public void printContributor() {
        System.out.println("Name: " + name);
        System.out.println("City: " + city);
        System.out.println("Country: " + country);
        System.out.println("Phone: " + phone);
        System.out.println("Contribution: " + contribution);
        System.out.println("ID: " + id);
        System.out.println();
    }

    public static void binarySearch(Contributor [] contributorArray, String name) {
        System.out.println("***Binary Search for: " + name + "***");
		
		//perform a binary search for the name parameter in the 
		//contributorArray parameter
		
		//start your search in the middle of the array
		//and reduce the search scope by half until the value is found
		
		//hint - use the String.compareTo() function 
		
		//if a match is found, display the contributor object
		
		//if a match is not found, display a "not found" message

	}
}
