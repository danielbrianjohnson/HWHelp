public class Stack {
    Node first; 
 
    public Stack(){
        first = null;
    }
   
    public void push(Node newNode){           
		//defined in IP 1
    }
 
    public Node pop() {         
		//defined in IP 1
    }
    
    public void print() {
        Node tempDisplay = first; // start at the beginning of linkedList
           
        while (tempDisplay != null){ // Executes until we don't find end of list.
            tempDisplay.displayNode();
            tempDisplay = tempDisplay.next; // move to next Node
        }
           

    }
}
