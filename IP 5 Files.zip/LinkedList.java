public class LinkedList {
    Node first; 
 
    public LinkedList(){
        first = null;
    }
      
    public void printAll() {
        Node tempDisplay = first; // start at the beginning of linkedList
           
        while (tempDisplay != null){ // Executes until we don't find end of list.
            tempDisplay.displayNode();
            tempDisplay = tempDisplay.next; // move to next Node
        }
           
        System.out.println();
    }
    
    public void add(Node newNode) {
        //defined in IP 3
    }
    
    public void search(String name) {
		//defined in IP 4
    }
    
    public Contributor [] copyToArray() {
		//copy the entire linked list to an array
		//and return the array
		
    }
}
