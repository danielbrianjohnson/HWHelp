public class HashTable {
    Stack [] table;
    
    public HashTable(int size) {
        table = new Stack[size];
        
        for (int i=0; i < size; i++) {
            table[i] = new Stack();
        }
    }
    
    public void insert(Node n) {
        int hash = n.c.hashFunction();
        table[hash].push(n);
    }
    
    public void print() {
        for (int i=0; i < table.length; i++) {
            System.out.println("===== Position " + i + " ======\n");
            table[i].print();
            System.out.println("========= End ==========");
            System.out.println();
        }
    }
    
    public int hashFunction(int id) {
        return (id % 5);
    }
    
    public void search(int id) {
        boolean found = false;
        int hashID = hashFunction(id);
        Node temp = table[hashID].first;
        
        System.out.println("***Hash Search by ID***");
        
        while (!found && temp != null) {
            if (id == temp.c.getId()) {
                System.out.println(id + " found in: ");
                temp.displayNode();
                found = true;
            }
            
            temp = temp.next;
        }
        
        if (!found) {
            System.out.println(id + " not found.");
        }
    }
}
