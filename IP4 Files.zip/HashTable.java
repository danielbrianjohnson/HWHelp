public class HashTable {
    Stack [] table;
    
    public HashTable(int size) {
		//defined in IP 2
    }
    
    public void insert(Node n) {
        //defined in IP 3
    }
    
    public void print() {
		//display the contents of the entire hash table
        for (int i=0; i < table.length; i++) {
            System.out.println("===== Position " + i + " ======\n");
            table[i].print();
            System.out.println("========= End ==========");
            System.out.println();
        }
    }
    
    public int hashFunction(int id) {
        //calculate and return the has value (0-4) of the id parameter
    }
    
    public void search(int id) {
		//call the hashFunction in this class to calculate the key
		
		//use the key to sequentially search the hash table for the 
		//requested id
		
		//if the id is found, display the search value and the 
		//contents of the node
		
		//if the id is not found, display a "not found" message
		
    }
}
