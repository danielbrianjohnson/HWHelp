public class LinkedList {
    Node first; 
 
    public LinkedList(){
        first = null;
    }
      
    public void printAll() {
		//display the entire linked list
        Node tempDisplay = first; // start at the beginning of linkedList
           
        while (tempDisplay != null){ // Executes until we don't find end of list.
            tempDisplay.displayNode();
            tempDisplay = tempDisplay.next; // move to next Node
        }
           
        System.out.println();
    }
    
    public void add(Node newNode) {
        //defined in IP 3
    }
    
    public void search(String name) {
		//perform a "sequential search" of the linked list for the given 
		//name value
		
		//if a match is found, display the contents of the node
		
		//if no match is found, display a "not found" message

	}
}
