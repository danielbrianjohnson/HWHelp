public class LinkedList {
    Node first; 
 
    public LinkedList(){
        first = null;
    }
     
    public void printAll() {
		//display the contents of the entire list
        Node tempDisplay = first; // start at the beginning of linkedList
           
        while (tempDisplay != null){ // Executes until we don't find end of list.
            tempDisplay.displayNode();
            tempDisplay = tempDisplay.next; // move to next Node
        }
           
        System.out.println();
    }
    
    public void add(Node newNode) {
		//add newNode to its correct position in the linked list
		//based on the member variable "name" in contributor in 
		//alphabetical order
		
		//the logic for this method requires you to consider several
		//possible situations
		//1. There are no nodes in the list
		//2. The new node needs to be inserted before the first node
		//3. The new node needs to be inserted between two existing nodes
		//4. The new node needs to be inserted at the end of the list

    }
}
