public class Stack {
    Node first; 
 
    public Stack(){
        //this constructor was defined in IP 1
    }
   
    public void push(Node newNode){
        //this method was defined in IP 1
    }
 
    public Node pop() {         
        //this method was defined in IP 1
    }
    
    public void print() {
		//display the contents of the entire stack
        Node tempDisplay = first; // start at the beginning of linkedList
           
        while (tempDisplay != null){ // Executes until we don't find end of list.
            tempDisplay.displayNode();
            tempDisplay = tempDisplay.next; // move to next Node
        }
    }
}
