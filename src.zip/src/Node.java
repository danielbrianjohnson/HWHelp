public class Node {
    Contributor c;
    Node next;
    
    public Node(Contributor data){
        //initialize member variables
        c=data;
        next=null;
    }

   public void displayNode() {
	//display the contents of this node
        c.printContributor();
  }
}
 
 