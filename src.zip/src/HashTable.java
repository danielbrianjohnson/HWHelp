
import java.util.LinkedList;

public class HashTable {
    Stack[] table;
    
    public HashTable(int size) {
        //initialize the table array with empty Stack objects
        table = new Stack[size];

    }
    
    public void insert(Node n) {
		//determine the hash key of Node n
                int key = n.c.hashFunction();
                System.out.println(key);
		//using the key to determine the table location, 
		//push Node n onto the stack
                System.out.println(table[key]);
                   
                table[key].push(n);
         

                
    }
    
    public void print() {
		//display the contents of the entire table in order
        for (int i=0; i < table.length; i++) {
            System.out.println("===== Position " + i + " ======\n");
            table[i].print();
            System.out.println("========= End ==========");
            System.out.println();
        }
        
    }
}