public class Stack {
    Node first; 

    public Stack(){
        //initialize the empty stack
        first = null;
    }
   
    public void push(Node newNode){
        //if the stack is empty, make first point to new Node.
        if(first==null)
            first=newNode;  
        //if the stack is not empty, loop until we get to the end of the list,
        //then make the last Node point to new Node
        else
        {
            first=newNode;
            newNode = newNode.next;
         }
    }
 
    public Node pop() { 
        //if the stack is empty, return null
        if(first==null)
            return null;
        //Handle the case where there is only one Node in the stack  
        else if(first.next==null)
        {
            Node t=first;
            return t;   
        }
        //Handle the case where there are at Least two (or more) elements in the stack
        else
        {
            Node t=first;
            return t;   
        }  
    }
    
    public void print() {
        //display the entire stack
        Node tempDisplay = first; // start at the beginning of linkedList
        while (tempDisplay != null){ // Executes until we don't find end of list.
            tempDisplay.displayNode();
            tempDisplay = tempDisplay.next;
        }  
        System.out.println();
    }
}
